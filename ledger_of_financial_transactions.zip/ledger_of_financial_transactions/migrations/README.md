Single-database configuration for Flask.
