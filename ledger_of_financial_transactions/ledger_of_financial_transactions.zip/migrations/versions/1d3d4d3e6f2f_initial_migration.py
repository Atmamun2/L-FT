"""Initial migration

Revision ID: 1d3d4d3e6f2f
Revises: 
Create Date: 2025-11-16 14:58:25.346658

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '1d3d4d3e6f2f'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
